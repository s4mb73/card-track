/**
 * carriers.js
 * Lightweight status fetchers for Royal Mail, Evri, and DPD.
 * Returns a normalised status string:
 *   pending | in_transit | out_for_delivery | delivered | failed | unknown
 */

import fetch from 'node-fetch';

// ── Normalised status values ──────────────────────────────────────────────────
export const STATUS = {
  PENDING:           'pending',
  IN_TRANSIT:        'in_transit',
  OUT_FOR_DELIVERY:  'out_for_delivery',
  DELIVERED:         'delivered',
  FAILED:            'failed',
  UNKNOWN:           'unknown',
};

export const STATUS_LABELS = {
  pending:           'Pending',
  in_transit:        'In transit',
  out_for_delivery:  'Out for delivery',
  delivered:         'Delivered',
  failed:            'Delivery failed',
  unknown:           'Unknown',
};

// ── Helper: fetch page HTML with a browser-like UA ───────────────────────────
async function getHTML(url) {
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; CardTrack/1.0)',
      'Accept': 'text/html,application/xhtml+xml',
    },
    timeout: 12000,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} from ${url}`);
  return res.text();
}

// ── Royal Mail ────────────────────────────────────────────────────────────────
// Uses their unofficial summary API used by the tracking page.
async function checkRoyalMail(ref) {
  try {
    const url = `https://api.royalmail.com/track/v2/events/${encodeURIComponent(ref)}`;
    const res = await fetch(url, {
      headers: {
        'Accept': 'application/json',
        'X-IBM-Client-Id': 'Royal Mail web client', // public web client key
        'User-Agent': 'Mozilla/5.0 (compatible; CardTrack/1.0)',
      },
      timeout: 12000,
    });

    if (!res.ok) {
      // Fall back to HTML scrape
      return await checkRoyalMailHTML(ref);
    }

    const data = await res.json();
    const events = data?.mailPieces?.[0]?.events ?? [];
    const latest = events[0]?.eventCode ?? '';

    // Royal Mail event codes → normalised status
    const delivered = ['DDDA','DDDB','DDDC','DDDD','DDDE','DDDF','LD01','EVRD'];
    const outForDelivery = ['EVNI','DDNA','DDNB','DDNC'];
    const inTransit = ['EVUA','EVUB','EVGA','EVGB','EVHH','MECE','EVHG'];
    const failed = ['NDNA','NDNB','NDNC','NDND'];

    if (delivered.includes(latest))        return STATUS.DELIVERED;
    if (outForDelivery.includes(latest))   return STATUS.OUT_FOR_DELIVERY;
    if (failed.includes(latest))           return STATUS.FAILED;
    if (inTransit.includes(latest))        return STATUS.IN_TRANSIT;
    if (events.length > 0)                 return STATUS.IN_TRANSIT;
    return STATUS.PENDING;

  } catch {
    return await checkRoyalMailHTML(ref).catch(() => STATUS.UNKNOWN);
  }
}

async function checkRoyalMailHTML(ref) {
  const html = await getHTML(
    `https://www.royalmail.com/track-your-item#/tracking-results/${ref}`
  );
  const lower = html.toLowerCase();
  if (lower.includes('delivered'))         return STATUS.DELIVERED;
  if (lower.includes('out for delivery'))  return STATUS.OUT_FOR_DELIVERY;
  if (lower.includes('with our courier'))  return STATUS.OUT_FOR_DELIVERY;
  if (lower.includes('in transit'))        return STATUS.IN_TRANSIT;
  if (lower.includes('item received'))     return STATUS.IN_TRANSIT;
  if (lower.includes('sorry'))             return STATUS.FAILED;
  return STATUS.UNKNOWN;
}

// ── Evri ──────────────────────────────────────────────────────────────────────
async function checkEvri(ref) {
  try {
    const url = `https://api.hermesworld.co.uk/enterprise-tracking-api/v2/parcels/${encodeURIComponent(ref)}`;
    const res = await fetch(url, {
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (compatible; CardTrack/1.0)',
      },
      timeout: 12000,
    });

    if (!res.ok) return await checkEvriHTML(ref);

    const data = await res.json();
    const state = (data?.parcel?.parcelStatusDescription ?? '').toLowerCase();

    if (state.includes('delivered'))         return STATUS.DELIVERED;
    if (state.includes('out for delivery'))  return STATUS.OUT_FOR_DELIVERY;
    if (state.includes('transit'))           return STATUS.IN_TRANSIT;
    if (state.includes('sorted'))            return STATUS.IN_TRANSIT;
    if (state.includes('received'))          return STATUS.IN_TRANSIT;
    return STATUS.IN_TRANSIT;

  } catch {
    return await checkEvriHTML(ref).catch(() => STATUS.UNKNOWN);
  }
}

async function checkEvriHTML(ref) {
  const html = await getHTML(`https://www.evri.com/track/${ref}`);
  const lower = html.toLowerCase();
  if (lower.includes('delivered'))         return STATUS.DELIVERED;
  if (lower.includes('out for delivery'))  return STATUS.OUT_FOR_DELIVERY;
  if (lower.includes('in transit'))        return STATUS.IN_TRANSIT;
  if (lower.includes('on its way'))        return STATUS.IN_TRANSIT;
  return STATUS.UNKNOWN;
}

// ── DPD ───────────────────────────────────────────────────────────────────────
async function checkDPD(ref) {
  try {
    const url = `https://track.dpd.co.uk/tracking/parcel/${encodeURIComponent(ref)}`;
    const html = await getHTML(url);
    const lower = html.toLowerCase();

    if (lower.includes('delivered'))           return STATUS.DELIVERED;
    if (lower.includes('out for delivery'))    return STATUS.OUT_FOR_DELIVERY;
    if (lower.includes('with driver'))         return STATUS.OUT_FOR_DELIVERY;
    if (lower.includes('in transit'))          return STATUS.IN_TRANSIT;
    if (lower.includes('at depot'))            return STATUS.IN_TRANSIT;
    if (lower.includes('collection'))          return STATUS.IN_TRANSIT;
    return STATUS.UNKNOWN;
  } catch {
    return STATUS.UNKNOWN;
  }
}

// ── Yodel ─────────────────────────────────────────────────────────────────────
async function checkYodel(ref) {
  try {
    const html = await getHTML(`https://www.yodel.co.uk/tracking/${ref}`);
    const lower = html.toLowerCase();
    if (lower.includes('delivered'))           return STATUS.DELIVERED;
    if (lower.includes('out for delivery'))    return STATUS.OUT_FOR_DELIVERY;
    if (lower.includes('in transit'))          return STATUS.IN_TRANSIT;
    return STATUS.UNKNOWN;
  } catch {
    return STATUS.UNKNOWN;
  }
}

// ── Public API ─────────────────────────────────────────────────────────────────
export async function checkTracking(carrier, ref) {
  if (!ref || ref.trim() === '') return STATUS.PENDING;

  switch (carrier) {
    case 'royal_mail': return checkRoyalMail(ref);
    case 'evri':       return checkEvri(ref);
    case 'dpd':        return checkDPD(ref);
    case 'yodel':      return checkYodel(ref);
    default:           return STATUS.UNKNOWN;
  }
}
